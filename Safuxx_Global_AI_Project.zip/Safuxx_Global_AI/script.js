const $ = id => document.getElementById(id);
const chat = $("chat");
let recognition = null;
let listening = false;
let keepListening = false;
let waitingForTask = false;
let voiceEnabled = true;
let busy = false;

function addBubble(role, text, sources = []) {
  const box = document.createElement("div");
  box.className = "bubble " + (role === "You" ? "user" : "assistant");
  const label = document.createElement("b");
  label.textContent = role;
  box.appendChild(label);
  const body = document.createElement("p");
  body.textContent = text;
  box.appendChild(body);

  if (sources.length) {
    const list = document.createElement("div");
    list.style.marginTop = "10px";
    const title = document.createElement("b");
    title.textContent = "Sources";
    list.appendChild(title);
    sources.forEach(source => {
      if (!source.url) return;
      const p = document.createElement("p");
      const a = document.createElement("a");
      a.href = source.url;
      a.target = "_blank";
      a.rel = "noopener noreferrer";
      a.textContent = source.title || source.url;
      p.appendChild(a);
      list.appendChild(p);
    });
    box.appendChild(list);
  }
  chat.appendChild(box);
  chat.scrollTop = chat.scrollHeight;
  return box;
}

function speak(text) {
  if (!voiceEnabled || !("speechSynthesis" in window)) return;
  speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "en-IN";
  utterance.rate = 1;
  speechSynthesis.speak(utterance);
}

function say(text, sources = []) {
  addBubble("Safuxx", text, sources);
  $("status").textContent = text.length > 70 ? text.slice(0, 67) + "…" : text;
  speak(text);
}

function startListening() {
  const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!Recognition) {
    say("Voice recognition is not supported by this browser. Try Chrome or type your question.");
    return;
  }
  if (listening) return;

  keepListening = true;
  recognition = new Recognition();
  recognition.lang = "en-IN";
  recognition.continuous = true;
  recognition.interimResults = false;
  recognition.onstart = () => {
    listening = true;
    $("orb").classList.add("listening");
    $("status").textContent = 'Listening for "Hey Safuxx"...';
  };
  recognition.onresult = event => {
    for (let i = event.resultIndex; i < event.results.length; i++) {
      if (!event.results[i].isFinal) continue;
      const text = event.results[i][0].transcript.trim();
      addBubble("You", text);
      if (/hey\s+safuxx|^safuxx[.!]?$/i.test(text)) {
        waitingForTask = true;
        say("Yes, I'm here! What task should I do?");
      } else if (waitingForTask) {
        waitingForTask = false;
        askSafuxx(text, true);
      } else {
        askSafuxx(text, true);
      }
    }
  };
  recognition.onerror = event => {
    $("status").textContent = "Voice error: " + event.error;
    if (event.error === "not-allowed") keepListening = false;
  };
  recognition.onend = () => {
    listening = false;
    $("orb").classList.remove("listening");
    if (keepListening) {
      setTimeout(() => {
        if (keepListening && recognition) {
          try { recognition.start(); } catch (_) {}
        }
      }, 600);
    } else {
      $("status").textContent = "Safuxx is ready";
    }
  };
  try { recognition.start(); }
  catch (_) { $("status").textContent = "Could not start microphone"; }
}

function stopListening() {
  keepListening = false;
  waitingForTask = false;
  if (recognition) {
    try { recognition.stop(); } catch (_) {}
  }
  listening = false;
  $("orb").classList.remove("listening");
  $("status").textContent = "Listening stopped";
}

async function askSafuxx(text, fromVoice = false) {
  text = text.trim();
  if (!text || busy) return;
  if (text.toLowerCase() === "stop listening") {
    stopListening();
    say("Okay, I stopped listening.");
    return;
  }

  // Handle a few safe, local commands without an AI request.
  const lower = text.toLowerCase();
  if (lower.includes("what time is it") || lower === "time") {
    say("The time is " + new Date().toLocaleTimeString());
    return;
  }
  if (lower.includes("today's date") || lower === "date" || lower.includes("what date")) {
    say("Today is " + new Date().toLocaleDateString(undefined, {
      weekday: "long", year: "numeric", month: "long", day: "numeric"
    }));
    return;
  }
  if (lower.startsWith("open youtube")) {
    window.open("https://youtube.com", "_blank", "noopener");
    say("Opening YouTube.");
    return;
  }
  if (lower.startsWith("open google")) {
    window.open("https://google.com", "_blank", "noopener");
    say("Opening Google.");
    return;
  }

  busy = true;
  $("sendBtn").disabled = true;
  $("status").textContent = "Safuxx is researching...";
  const placeholder = addBubble("Safuxx", "Thinking and checking available information...");
  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: text })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Request failed");
    placeholder.remove();
    say(data.reply || "I didn't receive an answer.", data.sources || []);
  } catch (error) {
    placeholder.remove();
    say("I couldn't connect to the AI server. Make sure the server is running and your API key is configured. Details: " + error.message);
  } finally {
    busy = false;
    $("sendBtn").disabled = false;
  }
}

$("startBtn").addEventListener("click", startListening);
$("stopBtn").addEventListener("click", stopListening);
$("sendBtn").addEventListener("click", () => {
  const input = $("prompt");
  const text = input.value.trim();
  if (!text) return;
  addBubble("You", text);
  input.value = "";
  askSafuxx(text);
});
$("prompt").addEventListener("keydown", event => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    $("sendBtn").click();
  }
});
$("voiceBtn").addEventListener("click", () => {
  voiceEnabled = !voiceEnabled;
  $("voiceBtn").textContent = voiceEnabled ? "🔊 Voice on" : "🔇 Voice off";
  if (!voiceEnabled && "speechSynthesis" in window) speechSynthesis.cancel();
});
$("clearBtn").addEventListener("click", () => chat.replaceChildren());
document.querySelectorAll("[data-prompt]").forEach(button => {
  button.addEventListener("click", () => {
    $("prompt").value = button.dataset.prompt;
    $("sendBtn").click();
  });
});
