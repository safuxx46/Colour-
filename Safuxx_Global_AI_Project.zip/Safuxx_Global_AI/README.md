# Safuxx Global AI

A starter project for a voice-enabled personal assistant with an AI backend and web search for current information.

## Requirements
- Node.js 18 or newer
- An API key for the AI provider used by this example
- Internet connection

## Run in VS Code
1. Extract the project ZIP and open the folder in VS Code.
2. Open the VS Code terminal in this folder.
3. Run `npm install`
4. Copy `.env.example` to `.env`.
5. Add your own API key to `.env`. Never share or publish this file.
6. Run `npm start`
7. Open `http://localhost:3000` in your browser.

## Features
- Chat interface and spoken answers
- Browser speech recognition in supported browsers
- “Hey Safuxx” phrase detection while the page is actively listening
- AI responses across many subjects
- Web search tool for current/world information when supported by your model/API account
- Quick prompts and source links when the API returns them

## Important limitations
- The assistant does not literally know all facts and can make mistakes. Web search can improve current answers but cannot guarantee completeness.
- API usage may cost money depending on provider pricing and account.
- Browser wake-word listening is not reliable when the page is closed or backgrounded. An always-on wake word needs a native Android app, a wake-word engine, permissions, and battery/background handling.
- This starter cannot control all phone apps or safely execute arbitrary tasks. Each real-world action needs an explicit integration, Android permission, and often user confirmation.
- The frontend expects the server at the same origin. Do not open `index.html` directly when using the AI endpoint.
