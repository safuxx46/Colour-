require("dotenv").config();
const express = require("express");
const OpenAI = require("openai");
const path = require("path");

const app = express();
app.use(express.json({ limit: "1mb" }));
app.use(express.static(__dirname));

const apiKey = process.env.OPENAI_API_KEY;
const model = process.env.OPENAI_MODEL || "gpt-5";
const client = apiKey ? new OpenAI({ apiKey }) : null;

const instructions = `
You are Safuxx, a helpful personal AI assistant for a user anywhere in the world.
Answer questions about global knowledge, geography, history, science, technology,
education, programming, maths, writing, and everyday planning.
For questions involving current events, latest facts, changing prices, live information,
or other time-sensitive topics, use web search when available. Clearly distinguish
verified facts from uncertainty, give dates when relevant, and include source links
when available. Do not invent citations or pretend to have checked a source if you have not.
Be friendly, clear, and useful. Match the user's language when practical.
You cannot directly control the user's phone or perform actions outside this app unless
a specifically configured tool/integration enables it. Never claim an action succeeded
unless it actually did. Ask for confirmation before consequential external actions.
For medical, legal, financial, or safety-critical topics, be cautious and encourage checking
qualified or official sources.
`;

app.post("/api/chat", async (req, res) => {
  try {
    if (!client) {
      return res.status(503).json({
        error: "OPENAI_API_KEY is missing. Add it to your .env file and restart the server."
      });
    }

    const message = String(req.body?.message || "").trim();
    if (!message) return res.status(400).json({ error: "Message is required." });
    if (message.length > 12000) {
      return res.status(413).json({ error: "Message is too long." });
    }

    const result = await client.responses.create({
      model,
      instructions,
      input: message,
      tools: [{ type: "web_search" }]
    });

    const reply = result.output_text || "I couldn't produce a text answer.";
    const sources = [];
    for (const item of (result.output || [])) {
      if (item.type !== "message") continue;
      for (const content of (item.content || [])) {
        for (const annotation of (content.annotations || [])) {
          if (annotation.type === "url_citation" && annotation.url) {
            if (!sources.some(s => s.url === annotation.url)) {
              sources.push({
                title: annotation.title || annotation.url,
                url: annotation.url
              });
            }
          }
        }
      }
    }

    res.json({ reply, sources });
  } catch (error) {
    console.error("Safuxx API error:", error.message);
    res.status(500).json({
      error: "AI request failed. Check your API key, model access, and network settings."
    });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => {
  console.log(`Safuxx AI is running at http://localhost:${port}`);
});
